Conteúdo de exemplo: README.txt
