Conteúdo de exemplo: simulation_utils.py
