Conteúdo de exemplo: quantum_crypto.py
