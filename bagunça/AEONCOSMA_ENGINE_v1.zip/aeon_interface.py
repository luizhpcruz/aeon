# aeon_interface.py
from aeoncosma_engine import ciclo

def executar_ciclos(n=13):
    for _ in range(n):
        ciclo()

if __name__ == "__main__":
    executar_ciclos()
